KRYSTAL BALL — FIRST WEBSITE VERSION

Files:
- index.html: complete responsive single-page website and app-style demo.

Included:
- Celestial dark-plum visual style
- Responsive navigation and sections
- Tarot service pricing
- Course and manifestation bundle listings
- Physical art/merch shop listings
- Order request form with browser-local demo storage
- Client portal preview
- 18+ confirmation gate for the adult-reading request
- Export/clear demo requests

IMPORTANT LIMITATIONS:
This is a front-end prototype, not a production commerce system.
- Requests are stored only in the current browser's local storage; they are NOT sent to Krystal.
- No secure login, server database, email notifications, payment processing, inventory, shipping, video hosting, or live booking calendar is connected.
- Do not collect sensitive client information using this demo.
- The 18+ prompt is a simple confirmation, not robust age verification.
- Replace placeholder product descriptions and add your real art/photos before publishing.

To preview:
Open index.html in a browser.

To publish free:
1. Create a GitHub account and a new public repository named krystal-ball (or another name).
2. Upload index.html to the repository root.
3. In repository Settings > Pages, enable deployment from the main branch and root folder.
4. GitHub Pages will provide a public URL after deployment. A custom domain is optional and usually costs money.
Alternative: use a static hosting service's free tier to deploy the folder.

Before accepting real orders:
Connect a secure form/backend and payment provider, add privacy/refund/shipping policies, confirm product fulfillment, and test on mobile. For a beginner-friendly launch, use a hosted storefront/booking service for payments rather than storing card data yourself.
